<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Profil Pengguna</h4>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <!-- Bagian Update Informasi Profil -->
                    <div class="mt-4">
                        <h5 class="text-primary">Update Informasi Profil</h5>
                        <div class="card p-4 bg-light shadow-sm rounded">
                            <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>

                    <!-- Bagian Update Password -->
                    <div class="mt-4">
                        <h5 class="text-primary">Update Password</h5>
                        <div class="card p-4 bg-light shadow-sm rounded">
                            <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>

                    <!-- Bagian Hapus Akun -->
                    <div class="mt-4">
                        <h5 class="text-danger">Hapus Akun</h5>
                        <div class="card p-4 bg-light shadow-sm rounded">
                            <?php echo $__env->make('profile.partials.delete-user-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\skripsi\skipsi-pemancingan-laravel\resources\views/profile/edit.blade.php ENDPATH**/ ?>