

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Detail Jadwal Anda</h4>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>

                        <div class="table-responsive mt-3">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>
                                            <a
                                                href="<?php echo e(route('pages.schedule.indexUser', ['sort' => 'activity_name', 'direction' => $sortField === 'activity_name' && $sortDirection === 'asc' ? 'desc' : 'asc'])); ?>">
                                                Aktivitas
                                                <?php if($sortField === 'activity_name'): ?>
                                                    <?php if($sortDirection === 'asc'): ?>
                                                        ▲
                                                    <?php else: ?>
                                                        ▼
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </a>
                                        </th>
                                        <th>
                                            <a
                                                href="<?php echo e(route('pages.schedule.indexUser', ['sort' => 'date', 'direction' => $sortField === 'date' && $sortDirection === 'asc' ? 'desc' : 'asc'])); ?>">
                                                Tanggal
                                                <?php if($sortField === 'date'): ?>
                                                    <?php if($sortDirection === 'asc'): ?>
                                                        ▲
                                                    <?php else: ?>
                                                        ▼
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </a>
                                        </th>
                                        <th>
                                            <a
                                                href="<?php echo e(route('pages.schedule.indexUser', ['sort' => 'time', 'direction' => $sortField === 'time' && $sortDirection === 'asc' ? 'desc' : 'asc'])); ?>">
                                                Waktu
                                                <?php if($sortField === 'time'): ?>
                                                    <?php if($sortDirection === 'asc'): ?>
                                                        ▲
                                                    <?php else: ?>
                                                        ▼
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </a>
                                        </th>
                                        <th>
                                            Maximal Quantity
                                        </th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($schedule->activity_name); ?></td>
                                            <td><?php echo e($schedule->date); ?></td>
                                            <td><?php echo e($schedule->hours_remaining); ?></td>
                                            <td><?php echo e($schedule->maxqty); ?> - (<?php echo e($schedule->schedule_details_count); ?>)</td>
                                            <!-- Updated line -->
                                            <td>
                                                <a href="<?php echo e(route('pages.schedule.daftarschedule.indexUser', $schedule->id_schedule)); ?>"
                                                    class="btn btn-sm btn-warning">Daftar</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>

                        <div class="mt-3">
                            <nav aria-label="Page navigation">
                                <ul class="pagination pagination-sm justify-content-center">
                                    <?php echo e($schedules->links('vendor.pagination.bootstrap-4')); ?>

                                </ul>
                            </nav>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\skripsi\skipsi-pemancingan-laravel\resources\views/pages/schedule/indexUser.blade.php ENDPATH**/ ?>