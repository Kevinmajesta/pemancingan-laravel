<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
      <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024.  Premium from R&Y Fishing Kuala Kapuas. All rights reserved.</span>
    </div>
  </footer>
